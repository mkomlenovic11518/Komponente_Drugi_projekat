package com.raf.cinemauserservice.client;
import java.io.IOException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;

@Configuration
public class KarteServiceClientConfiguration {
	@Bean
	public RestTemplate karteServiceRestTemplate() {
		RestTemplate rt=new RestTemplate();
		rt.setUriTemplateHandler(new DefaultUriBuilderFactory("http://localhost:8084/karte-service/api"));
		return rt;
	}
	private class TokenInterceptor implements ClientHttpRequestInterceptor {

        @Override
        public ClientHttpResponse intercept(HttpRequest request, byte[] body,
                                            ClientHttpRequestExecution execution) throws IOException {
            HttpHeaders headers = request.getHeaders();
            headers.add("Authorization", "5aa0c841d86642fca19dac9665b33e55");
            return execution.execute(request, body);
        }
    }

}
