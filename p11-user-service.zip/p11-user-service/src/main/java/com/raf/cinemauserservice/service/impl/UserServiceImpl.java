package com.raf.cinemauserservice.service.impl;


import com.raf.cinemauserservice.configuration.EmailController;
import com.raf.cinemauserservice.domain.PlatneKartice;
import com.raf.cinemauserservice.domain.User;
import com.raf.cinemauserservice.domain.UserStatus;
import com.raf.cinemauserservice.dto.*;
import com.raf.cinemauserservice.exception.NotFoundException;
import com.raf.cinemauserservice.mapper.UserMapper;
import com.raf.cinemauserservice.repository.PlatneKarticeRepository;
import com.raf.cinemauserservice.repository.UserRepository;
import com.raf.cinemauserservice.repository.UserStatusRepository;
import com.raf.cinemauserservice.secutiry.service.TokenService;
import com.raf.cinemauserservice.service.UserService;


import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	 private TokenService tokenService;
	    private UserRepository userRepository;
	    private UserStatusRepository userStatusRepository;
	    private PlatneKarticeRepository platneKarticeRepository;
	    private UserMapper userMapper;

	    public UserServiceImpl(UserRepository userRepository, TokenService tokenService, UserStatusRepository userStatusRepository, UserMapper userMapper,
	    		               PlatneKarticeRepository platneKarticeRepository) {
	        this.userRepository = userRepository;
	        this.tokenService = tokenService;
	        this.userMapper = userMapper;
	        this.userStatusRepository = userStatusRepository;
	        this.platneKarticeRepository=platneKarticeRepository;
	    }

	    @Override
	    public Page<UserDto> findAll(Pageable pageable) {
	        return userRepository.findAll(pageable)
	                .map(userMapper::userToUserDto);
	    }
	    
	    @Override
	    public Page<PlatneKarticeDto> findAllkartice(Long userId, Pageable pageable) {
	       
	    	
	    	return platneKarticeRepository.findByUserId(userId,pageable)
	                .map(userMapper::platneKarticeToPlatneKarticeDto);
	    }
	    @Override
	    public UserDto cancelKupovina(Long id) {
	    	User user = userRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("User with id: %d not found.", id)));
	    	// slanje maila
	    	 String ref = "Otkazana vam je karta za putovanje Avionom. moyete se javiti nasem office-u";
		       
		        
		        EmailController ec = new EmailController();
		        try {
		        	ec.sendmail(user.getEmail(), "Informacija :" +user.getFirstName() +" "+ user.getLastName(), ref);
		        }catch(Exception e) {
		        	
		        }
	    
	    	UserDto dt= userMapper.userToUserDto(user);
	    	return dt;
	    }
	    
	    @Override
	    public UserDto findById(Long id) {
	    	User user = userRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("User with id: %d not found.", id)));
	    
	    	UserDto dt= userMapper.userToUserDto(user);
	    	return dt;
	    }
	    
	   
	    
	    @Override
	    public void deleteById(Long id) {
	        userRepository.deleteById(id);
	    }

	    @Override
	    public DiscountDto findDiscount(Long id) {
	        User user = userRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("User with id: %d not found.", id)));
	        List<UserStatus> userStatusList = userStatusRepository.findAll();
	        //get discount
	        Integer discount = userStatusList.stream()
	                .filter(userStatus -> userStatus.getMaxNumberOfMilles() >= user.getNumberOfMilles()
	                        && userStatus.getMinNumberOfMilles() <= user.getNumberOfMilles())
	                .findAny()
	                .get()
	                .getDiscount();
	        return new DiscountDto(discount);
	    }

	    @Override
	    public UserDto add(UserCreateDto userCreateDto) { //ADMINISTRATORSKO DODAVANJE
	        User user = userMapper.userCreateDtoToUser(userCreateDto,0);
	        userRepository.save(user);
	        return userMapper.userToUserDto(user);
	    }
	    
	    @Override
	    public UserDto register(UserCreateDto userCreateDto) { //REGISTRACIJA
	        User user = userMapper.userCreateDtoToUser(userCreateDto,1);
	        userRepository.save(user);
	        return userMapper.userToUserDto(user);
	    }
	    @Override
	    public String confirmToken(String token) {
	    		//verifikacija tokena
	    	User user = userRepository
	                .findUserByToken(token)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("Ne postoji korisnik sa datim parametrom", token)));
	    	user.setDozvoljen(1);
	    	userRepository.save(user);
	    	return "USPESNA KONFIRMACIJA";
	    }
	    
	    @Override
	    public UserDto updateUser(Long id, UserCreateDto userCreateDto) {
	    	User user = userRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("User with id: %d not found.", id)));
	    	 user = userMapper.userUpdateDtoToUser(user, userCreateDto);
	    	userRepository.save(user);
	        return userMapper.userToUserDto(user);
	    	
	    }

	    @Override
	    public TokenResponseDto login(TokenRequestDto tokenRequestDto) {
	        //Try to find active user for specified credentials
	        User user = userRepository
	                .findUserByEmailAndPassword(tokenRequestDto.getEmail(), tokenRequestDto.getPassword())
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("User with email: %s and password: %s not found.", tokenRequestDto.getEmail(),
	                                tokenRequestDto.getPassword())));
	        
	     
	        if(user.getDozvoljen()!=1) {
	        	throw new NotFoundException(String
	                        .format("User sa email: %s and password: %s nije aktiviran.", tokenRequestDto.getEmail(),
	                                tokenRequestDto.getPassword()));
	        	
	        }
	        else {
		        //Create token payload
		        Claims claims = Jwts.claims();
		        claims.put("id", user.getId());
		        claims.put("role", user.getRole().getName());
		        //Generate token
		        return new TokenResponseDto(tokenService.generate(claims));
	        }
	    }
	    
	    //novododate metode
	    @Override
	    public NumberOfMillesDto changeNumberOfMilles(Long id, Integer numOfMilesInFlight) {
	    	User user = userRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("User with id: %d not found.", id)));
	    	Integer br= user.getNumberOfMilles();
	    	user.setNumberOfMilles(br+numOfMilesInFlight);
	    	userRepository.save(user); // ovo treba da uradi update
	    	return new NumberOfMillesDto(br+numOfMilesInFlight);
	    }
	    
	    @Override
	    public PlatneKarticeDto add(PlatneKarticeCreateDto platneKarticeCreateDto) {
	    	User user = userRepository
	                .findById(platneKarticeCreateDto.getUserId())
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("User with id: %d not found.", platneKarticeCreateDto.getUserId())));
	    	
	    	PlatneKartice pk = userMapper.platneKarticeCreateDtoToPlatneKartice(user,platneKarticeCreateDto);
	    	platneKarticeRepository.save(pk);
	    	return userMapper.platneKarticeToPlatneKarticeDto(pk);
	    }
	    
	    @Override
	    public PlatneKarticeDto update(Long id, PlatneKarticeCreateDto platneKarticeCreateDto) {
	    	PlatneKartice pk = userMapper.platneKarticeUpdateDtoToPlatneKartice(id, platneKarticeCreateDto);
	    	platneKarticeRepository.save(pk);
	    	return userMapper.platneKarticeToPlatneKarticeDto(pk);
	    }
	    
	    
	}
