package com.raf.cinemauserservice.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;



@Entity
public class PlatneKartice {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	@Column(name = "ime")
    private String ime;
	@Column(name = "prezime")
    private String prezime;
    private String brojKartice;
    private String sigurnosniBroj;
    @ManyToOne
    private User user;

    public PlatneKartice() {

    }
    
    public PlatneKartice(String ime, String prezime, String br, String sigBroj, User us) {
        this.setIme(ime);
        this.setPrezime(prezime);
        this.setBrojKartice(br);
        this.setSigurnosniBroj(sigBroj);
        this.user=us;
    }

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public String getBrojKartice() {
		return brojKartice;
	}

	public void setBrojKartice(String brojKartice) {
		this.brojKartice = brojKartice;
	}

	public String getSigurnosniBroj() {
		return sigurnosniBroj;
	}

	public void setSigurnosniBroj(String sigurnosniBroj) {
		this.sigurnosniBroj = sigurnosniBroj;
	}
	
	 public User getUser() {
	        return user;
	    }

	    public void setUser(User user) {
	        this.user = user;
	    }
	    
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }


}
