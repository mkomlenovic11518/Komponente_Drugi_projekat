package com.raf.cinemauserservice.mapper;

import com.netflix.client.http.HttpResponse;
import com.raf.cinemauserservice.configuration.EmailController;
import com.raf.cinemauserservice.domain.Address;
import com.raf.cinemauserservice.domain.PlatneKartice;
import com.raf.cinemauserservice.domain.User;
import com.raf.cinemauserservice.dto.AddressDto;
import com.raf.cinemauserservice.dto.PlatneKarticeCreateDto;
import com.raf.cinemauserservice.dto.PlatneKarticeDto;
import com.raf.cinemauserservice.dto.UserCreateDto;
import com.raf.cinemauserservice.dto.UserDto;
import com.raf.cinemauserservice.exception.NotFoundException;
import com.raf.cinemauserservice.repository.PlatneKarticeRepository;
import com.raf.cinemauserservice.repository.RoleRepository;
import com.raf.cinemauserservice.repository.UserRepository;
import com.raf.cinemauserservice.secutiry.service.TokenService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {

	 private RoleRepository roleRepository;
	    private UserRepository userRepository;
	    private PlatneKarticeRepository platneKarticeRepository;

	    public UserMapper(RoleRepository roleRepository) {
	        this.roleRepository = roleRepository;
	    }

	    public UserDto userToUserDto(User user) {
      
        	
	    	UserDto userDto = new UserDto();
	        userDto.setId(user.getId());
	        userDto.setEmail(user.getEmail());
	        userDto.setFirstName(user.getFirstName());
	        userDto.setLastName(user.getLastName());
	        userDto.setUsername(user.getUsername());
	        userDto.setPasseport(user.getPasseport());
	        AddressDto ad=new AddressDto();
	        ad.setCountry(user.getAddress().getCountry()); 
	        ad.setCity(user.getAddress().getCity());
	        ad.setStreet(user.getAddress().getStreet());
	        ad.setNumber(user.getAddress().getNumber());
	        ad.setPostcode(user.getAddress().getPostcode());
	        ad.setApartmentNumber(user.getAddress().getApartmentNumber());
	        userDto.setAddressDto(ad);
	       
	        
	        userDto.setNumberOfMilles(user.getNumberOfMilles());
	        userDto.setDozvoljen(user.getDozvoljen());
	        
	        return userDto;
	    }

	    public User userCreateDtoToUser(UserCreateDto userCreateDto,int reg) {
	    	 
	        User user = new User();
	        user.setEmail(userCreateDto.getEmail());
	        user.setFirstName(userCreateDto.getFirstName());
	        user.setLastName(userCreateDto.getLastName());
	        user.setUsername(userCreateDto.getUsername());
	        user.setPassword(userCreateDto.getPassword());
	        user.setPasseport(userCreateDto.getPasseport());
	        user.setRole(roleRepository.findRoleByName("ROLE_USER").get());
	        user.setNumberOfMilles(0);
	        user.setDozvoljen(1);
	        if(reg==1) {
	        		// REGISTRACIJA, SALJE SE MAIL
			        //ovde cemo kreirati token i upisati ga
	        		user.setDozvoljen(0);
			        Claims claims=Jwts.claims();
			        claims.put(user.getEmail(), user.getLastName());
			        String token= Jwts.builder()
			                .setClaims(claims)
			                .signWith(SignatureAlgorithm.HS512, "kodna_rec")
			                .compact();
			        
			       
			        user.setToken(token);
			        StringBuffer sb = new StringBuffer();
			        sb.append((char)13);
			        sb.append((char)10);
			        String crlfTerminator = sb.toString();
			        String ref = "http://localhost:8084/user-service/api/user/" + token+"/confirm";
			        ref = ref+ crlfTerminator;
			        ref=ref + "potvrdi verifikaciju pritiskom na link";
			        EmailController ec = new EmailController();
			        try {
			        	ec.sendmail(user.getEmail(), "Verifikacija:" +user.getFirstName() +" "+ user.getLastName(), ref);
			        }catch(Exception e) {
			        	
			        }
	        }
	        
	        //Set address
	        Address address = new Address();
	        address.setCountry(userCreateDto.getAddress().getCountry());
	        address.setCity(userCreateDto.getAddress().getCity());
	        address.setPostcode(userCreateDto.getAddress().getPostcode());
	        address.setStreet(userCreateDto.getAddress().getStreet());
	        address.setNumber(userCreateDto.getAddress().getNumber());
	        address.setApartmentNumber(userCreateDto.getAddress().getApartmentNumber());
	        user.setAddress(address);
	        return user;
	    }
	    
	    public User userUpdateDtoToUser(User user, UserCreateDto userCreateDto) {
	    
	    	
	    	
	    	
	    	String oldEmail=user.getEmail();
	    	String newEmail=userCreateDto.getEmail();
	    	if(!oldEmail.equals(newEmail)) {
	    		// potrebna je vaerifikacija email
	    		user.setDozvoljen(0);
		        Claims claims=Jwts.claims();
		        claims.put(newEmail, user.getLastName());// pravi se token na bayi novog emaila
		        String token= Jwts.builder()
		                .setClaims(claims)
		                .signWith(SignatureAlgorithm.HS512, "kodna_rec")
		                .compact();
		        
		       
		        user.setToken(token);
		        StringBuffer sb = new StringBuffer();
		        sb.append((char)13);
		        sb.append((char)10);
		        String crlfTerminator = sb.toString();
		        String ref = "http://localhost:8084/user-service/api/user/" + token+"/confirm";
		        ref = ref+ crlfTerminator;
		        ref=ref + "potvrdi verifikaciju pritiskom na link";
		        EmailController ec = new EmailController();
		        try {
		        	ec.sendmail(user.getEmail(), "Verifikacija:" +user.getFirstName() +" "+ user.getLastName(), ref);
		        }catch(Exception e) {
		        	
		        }
	    		
	    	}
	    	
	        user.setEmail(userCreateDto.getEmail());
	        user.setFirstName(userCreateDto.getFirstName());
	        user.setLastName(userCreateDto.getLastName());
	        user.setUsername(userCreateDto.getUsername());
	        user.setPassword(userCreateDto.getPassword());
	        user.setPasseport(userCreateDto.getPasseport());
	        user.setRole(roleRepository.findRoleByName("ROLE_USER").get());
	        
	        user.getAddress().setCountry(userCreateDto.getAddress().getCountry());
	        user.getAddress().setCity(userCreateDto.getAddress().getCity());
	        user.getAddress().setPostcode(userCreateDto.getAddress().getPostcode());
	        user.getAddress().setStreet(userCreateDto.getAddress().getStreet());
	        user.getAddress().setNumber(userCreateDto.getAddress().getNumber());
	        user.getAddress().setApartmentNumber(userCreateDto.getAddress().getApartmentNumber());
	        
	        return user;
	    }
	    
	    public PlatneKarticeDto platneKarticeToPlatneKarticeDto(PlatneKartice pk) {
	    	
	    	PlatneKarticeDto pkDto = new PlatneKarticeDto();
	    	pkDto.setId(pk.getId());
	    	pkDto.setIme(pk.getIme());
	    	pkDto.setPrezime(pk.getPrezime());
	    	pkDto.setBrojKartice(pk.getBrojKartice());
	    	pkDto.setSigurnosniBroj(pk.getSigurnosniBroj());
	    	pkDto.setUserId(pk.getUser().getId());
	        return pkDto;
	    }
	    
	    public PlatneKartice platneKarticeCreateDtoToPlatneKartice(User user,PlatneKarticeCreateDto platneKarticeCreateDto) {
	    	
	    	
	    	PlatneKartice pk = new PlatneKartice();
	        pk.setIme(platneKarticeCreateDto.getIme());
	        pk.setPrezime(platneKarticeCreateDto.getPrezime());
	        pk.setBrojKartice(platneKarticeCreateDto.getBrojKartice());
	        pk.setSigurnosniBroj(platneKarticeCreateDto.getSigurnosniBroj());
	        pk.setUser(user);
	               
	        return pk;
	    }
	    
	    public PlatneKartice platneKarticeUpdateDtoToPlatneKartice(Long id, PlatneKarticeCreateDto platneKarticeCreateDto) {
	    	PlatneKartice pk = platneKarticeRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("Platna Kartica sa id: %d not found.", id)));
	    	
	        pk.setIme(platneKarticeCreateDto.getIme());
	        pk.setPrezime(platneKarticeCreateDto.getPrezime());
	        pk.setBrojKartice(platneKarticeCreateDto.getBrojKartice());
	        pk.setSigurnosniBroj(platneKarticeCreateDto.getSigurnosniBroj());
	        
	        return pk;
	    }
	}
