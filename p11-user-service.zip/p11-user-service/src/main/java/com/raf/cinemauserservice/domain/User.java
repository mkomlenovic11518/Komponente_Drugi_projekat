package com.raf.cinemauserservice.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(indexes = {@Index(columnList = "username", unique = true), @Index(columnList = "email", unique = true)})
public class User {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String email;
	    private String firstName;
	    private String lastName;
	    private String username;
	    private String password;
	    private String passeport;
	    private String token;
	    
	    @Embedded
	    private Address address;
	    @ManyToOne(optional = false)
	    private Role role;
	    private Integer numberOfMilles;
	    private Integer dozvoljen;
	    
	    @OneToMany(cascade = CascadeType.ALL, mappedBy = "user", orphanRemoval = true)
	   // private List<PlatneKartice> platneKartice = new ArrayList<>();

	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public String getFirstName() {
	        return firstName;
	    }

	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }

	    public String getLastName() {
	        return lastName;
	    }

	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }

	    public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
	        this.username = username;
	    }

	    public String getPassword() {
	        return password;
	    }

	    public void setPassword(String password) {
	        this.password = password;
	    }

	    public Address getAddress() {
	        return address;
	    }

	    public void setAddress(Address address) {
	        this.address = address;
	    }

	    public Role getRole() {
	        return role;
	    }

	    public void setRole(Role role) {
	        this.role = role;
	    }

	  

	 

		public String getPasseport() {
			return passeport;
		}

		public void setPasseport(String passeport) {
			this.passeport = passeport;
		}

		public Integer getNumberOfMilles() {
			return numberOfMilles;
		}

		public void setNumberOfMilles(Integer numberOfMilles) {
			this.numberOfMilles = numberOfMilles;
		}
		
		public Integer getDozvoljen() {
			return dozvoljen;
		}

		public void setDozvoljen(Integer Dozvoljen) {
			this.dozvoljen = Dozvoljen;
		}

		public String getToken() {
			return token;
		}

		public void setToken(String token) {
			this.token = token;
		}
		
		/*public List<PlatneKartice> getPlatneKartice() {
	        return platneKartice;
	    }

	    public void setPlatneKartice(List<PlatneKartice> platneKartice) {
	        this.platneKartice = platneKartice;
	    }*/

	}
