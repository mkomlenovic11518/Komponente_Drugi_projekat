package com.raf.cinemauserservice.dto;

import org.hibernate.validator.constraints.Length;



import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class UserCreateDto {

	 @Email
	    private String email;
	    @NotBlank
	    private String firstName;
	    @NotBlank
	    private String lastName;
	    @NotBlank
	    private String username;
	    @Length(min = 8, max = 20)
	    private String password;
	    @NotBlank
	    private String passeport;
	    
	    private int dozvoljen;

	    @NotNull
	    private AddressDto address;

	    public static class AddressDto {

	        @NotBlank
	        private String country;
	        @NotBlank
	        private String city;
	        private String postcode;
	        private String street;
	        private String number;
	        private String apartmentNumber;

	        public String getCountry() {
	            return country;
	        }

	        public void setCountry(String country) {
	            this.country = country;
	        }

	        public String getCity() {
	            return city;
	        }

	        public void setCity(String city) {
	            this.city = city;
	        }

	        public String getPostcode() {
	            return postcode;
	        }

	        public void setPostcode(String postcode) {
	            this.postcode = postcode;
	        }

	        public String getStreet() {
	            return street;
	        }

	        public void setStreet(String street) {
	            this.street = street;
	        }

	        public String getNumber() {
	            return number;
	        }

	        public void setNumber(String number) {
	            this.number = number;
	        }

	        public String getApartmentNumber() {
	            return apartmentNumber;
	        }

	        public void setApartmentNumber(String apartmentNumber) {
	            this.apartmentNumber = apartmentNumber;
	        }
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public String getFirstName() {
	        return firstName;
	    }

	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }

	    public String getLastName() {
	        return lastName;
	    }

	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }

	    public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
	        this.username = username;
	    }

	    public String getPassword() {
	        return password;
	    }

	    public void setPassword(String password) {
	        this.password = password;
	    }
	    
	    public String getPasseport() {
	        return passeport;
	    }

	    public void setPasseport(String passeport) {
	        this.passeport = passeport;
	    }

	    public AddressDto getAddress() {
	        return address;
	    }

	    public void setAddress(AddressDto address) {
	        this.address = address;
	    }

		public int getDozvoljen() {
			return dozvoljen;
		}

		public void setDozvoljen(int dozvoljen) {
			this.dozvoljen = dozvoljen;
		}
	}
