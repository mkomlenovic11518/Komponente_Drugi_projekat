package com.raf.cinemauserservice.exception;

public enum ErrorCode {
    RESOURCE_NOT_FOUND
}
