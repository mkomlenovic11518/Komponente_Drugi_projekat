package com.raf.cinemauserservice.service;



import com.raf.cinemauserservice.dto.*;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserService {

	 	Page<UserDto> findAll(Pageable pageable);

	    DiscountDto findDiscount(Long id);
	    
	    NumberOfMillesDto changeNumberOfMilles(Long id, Integer numOfMilesInFlight);

	    UserDto add(UserCreateDto userCreateDto); // dodavanje korisnika
	    
	    UserDto register(UserCreateDto userCreateDto); // registracija korisnika
	    
	    String confirmToken(String token); //verifikacija tokena
	    
	    UserDto updateUser(Long id, UserCreateDto userCreateDto); //update user
	    
	    PlatneKarticeDto add(PlatneKarticeCreateDto platneKarticeCreateDto);
	    
	    PlatneKarticeDto update(Long id, PlatneKarticeCreateDto platneKarticeCreateDto);

	    TokenResponseDto login(TokenRequestDto tokenRequestDto);
	    
	    UserDto findById(Long id);
	    
	    void deleteById(Long id);//brisanje usera
	    
	    Page<PlatneKarticeDto> findAllkartice(Long userId, Pageable pageable);
	    
	    UserDto cancelKupovina(Long id);
	}

