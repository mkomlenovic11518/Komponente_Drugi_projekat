package com.raf.cinemauserservice.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class UserStatus {

	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private Integer minNumberOfMilles;
	    private Integer maxNumberOfMilles;
	    private Integer discount;

	    public UserStatus() {

	    }

	    public UserStatus(Integer minNumberOfMilles, Integer maxNumberOfMilles, Integer discount) {
	        this.setMinNumberOfMilles(minNumberOfMilles);
	        this.setMaxNumberOfMilles(maxNumberOfMilles);
	        this.discount = discount;
	    }

	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	 

	    public Integer getDiscount() {
	        return discount;
	    }

	    public void setDiscount(Integer discount) {
	        this.discount = discount;
	    }

		public Integer getMinNumberOfMilles() {
			return minNumberOfMilles;
		}

		public void setMinNumberOfMilles(Integer minNumberOfMilles) {
			this.minNumberOfMilles = minNumberOfMilles;
		}

		public Integer getMaxNumberOfMilles() {
			return maxNumberOfMilles;
		}

		public void setMaxNumberOfMilles(Integer maxNumberOfMilles) {
			this.maxNumberOfMilles = maxNumberOfMilles;
		}
	}
