package com.raf.cinemauserservice.dto;

public class NumberOfMillesDto {
	private Integer numberOfMillesDto;

	public NumberOfMillesDto(Integer numberOfMillesDto) {
        this.numberOfMillesDto = numberOfMillesDto;
    }

    public NumberOfMillesDto() {

    }



	public Integer getNumberOfMillesDto() {
		return numberOfMillesDto;
	}



	public void setNumberOfMillesDto(Integer numberOfMillesDto) {
		this.numberOfMillesDto = numberOfMillesDto;
	}

    

}

