package com.raf.cinemauserservice.dto;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

public class PlatneKarticeCreateDto {
	@NotBlank
	private String ime;
	@NotBlank
    private String prezime;
	@NotBlank
    private String brojKartice;
	@Length(min = 3, max = 3)
    private String sigurnosniBroj;
	
    private Long userId;
	
	 public String getIme() {
	        return ime;
	 }

	 public void setIme(String ime) {
	        this.ime = ime;
	 }
	 public String getPrezime() {
	        return prezime;
	 }

	 public void setPrezime(String prezime) {
	        this.prezime = prezime;
	 }
	 public String getBrojKartice() {
	        return brojKartice;
	 }

	 public void setBrojKartice(String brojKartice) {
	        this.brojKartice = brojKartice;
	 }
	 public String getSigurnosniBroj() {
	        return sigurnosniBroj;
	 }

	 public void setSigurnosniBroj(String sigurnosniBroj) {
	        this.sigurnosniBroj = sigurnosniBroj;
	 }
	 public Long getUserId() {
	        return userId;
	 }

	 public void setUserId(Long userId) {
	        this.userId = userId;
	 }
	 

}


