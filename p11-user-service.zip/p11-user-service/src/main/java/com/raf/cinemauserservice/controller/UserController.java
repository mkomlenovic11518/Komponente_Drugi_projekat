package com.raf.cinemauserservice.controller;

import com.raf.cinemauserservice.dto.*;
import com.raf.cinemauserservice.secutiry.CheckSecurity;
import com.raf.cinemauserservice.service.UserService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/user")
public class UserController {

    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @ApiOperation(value = "Get all users")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", value = "What page number you want", dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "size", value = "Number of items to return", dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sort", allowMultiple = true, dataType = "string", paramType = "query",
                    value = "Sorting criteria in the format: property(,asc|desc). " +
                            "Default sort order is ascending. " +
                            "Multiple sort criteria are supported.")})
    @GetMapping
    @CheckSecurity(roles = {"ROLE_ADMIN", "ROLE_USER"})
    public ResponseEntity<Page<UserDto>> getAllUsers(@RequestHeader("Authorization") String authorization,
                                                     Pageable pageable) {

        return new ResponseEntity<>(userService.findAll(pageable), HttpStatus.OK);
    }
    
    @GetMapping("/{id}/platne")
    @CheckSecurity(roles = {"ROLE_ADMIN", "ROLE_USER"})
    public ResponseEntity<Page<PlatneKarticeDto>> getAllKartice(@RequestHeader("Authorization") String authorization,
    		@PathVariable("id") Long id, Pageable pageable) {

        return new ResponseEntity<>(userService.findAllkartice(id,pageable), HttpStatus.OK);
    }
    
    @PostMapping("/add_platna")
    @CheckSecurity(roles = {"ROLE_ADMIN","ROLE_USER"})
    public ResponseEntity<PlatneKarticeDto> add(@RequestHeader("Authorization") String authorization,
    		@RequestBody @Valid PlatneKarticeCreateDto platneKarticeCreateDto) {
        return new ResponseEntity<>(userService.add(platneKarticeCreateDto), HttpStatus.CREATED);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getUser(@PathVariable("id") Long id) {
    	
        return new ResponseEntity<UserDto>(userService.findById(id), HttpStatus.OK);
    }
    
    @DeleteMapping("/{id}/usr")
    @CheckSecurity(roles = {"ROLE_ADMIN"})
    public ResponseEntity<?> delete(@RequestHeader("Authorization") String authorization, @PathVariable("id") Long id) {
        userService.deleteById(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/{id}/discount")
    public ResponseEntity<DiscountDto> getDiscount(@PathVariable("id") Long id) {
        return new ResponseEntity<>(userService.findDiscount(id), HttpStatus.OK);
    }
    
    @GetMapping("/{id}/{milles}/changeMilles")
    public ResponseEntity<NumberOfMillesDto> changeMilles(@PathVariable("id") Long id,@PathVariable("milles") Integer milles) {
        return new ResponseEntity<>(userService.changeNumberOfMilles(id, milles), HttpStatus.OK);
    }
    
    @GetMapping("/{id}/cancelKupovine")
    public ResponseEntity<UserDto> cancelKupovina(@PathVariable("id") Long id) {
        return new ResponseEntity<>(userService.cancelKupovina(id), HttpStatus.OK);
    }
    // za inicijalnu registraciju nije neophodno da se unosi u putanju bilo sta
    @ApiOperation(value = "Register user")
    @PostMapping
    public ResponseEntity<UserDto> saveUser(@RequestBody @Valid UserCreateDto userCreateDto) {
        return new ResponseEntity<>(userService.register(userCreateDto), HttpStatus.CREATED);
    }
    
    @PostMapping("/add")
    @CheckSecurity(roles = {"ROLE_ADMIN"})
    public ResponseEntity<UserDto> addUser(@RequestBody @Valid UserCreateDto userCreateDto) {
        return new ResponseEntity<>(userService.add(userCreateDto), HttpStatus.CREATED);
    }
    
    @PutMapping(value = "/{id}")
    public ResponseEntity<UserDto> updateUser(@RequestHeader("Authorization") String authorization,
    		@PathVariable(value = "id") Long id,@RequestBody @Valid UserCreateDto userCreateDto) {
        return new ResponseEntity<UserDto>(userService.updateUser(id, userCreateDto), HttpStatus.OK);
    }
    
    @GetMapping("/{token}/confirm")
    public ResponseEntity<?> confirmToken(@PathVariable("token") String token) {
        return new ResponseEntity<>(userService.confirmToken(token), HttpStatus.OK);
    }

    @ApiOperation(value = "Login")
    @PostMapping("/login")
    public ResponseEntity<TokenResponseDto> loginUser(@RequestBody @Valid TokenRequestDto tokenRequestDto) {
        return new ResponseEntity<>(userService.login(tokenRequestDto), HttpStatus.OK);
    }
}
