package com.raf.cinemauserservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemaUserServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CinemaUserServiceApplication.class, args);
    }

}
