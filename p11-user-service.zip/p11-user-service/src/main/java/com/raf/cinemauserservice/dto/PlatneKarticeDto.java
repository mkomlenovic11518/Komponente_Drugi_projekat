package com.raf.cinemauserservice.dto;

import com.raf.cinemauserservice.domain.User;

public class PlatneKarticeDto {
	private Long id;
	private String ime;
    private String prezime;
    private String brojKartice;
    private String sigurnosniBroj;
    private Long userId;
	public String getIme() {
		return ime;
	}
	
	public PlatneKarticeDto() {}
	
	public void setIme(String ime) {
		this.ime = ime;
	}
	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	public String getBrojKartice() {
		return brojKartice;
	}
	public void setBrojKartice(String brojKartice) {
		this.brojKartice = brojKartice;
	}
	public String getSigurnosniBroj() {
		return sigurnosniBroj;
	}
	public void setSigurnosniBroj(String sigurnosniBroj) {
		this.sigurnosniBroj = sigurnosniBroj;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long user) {
		this.userId = user;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

}



