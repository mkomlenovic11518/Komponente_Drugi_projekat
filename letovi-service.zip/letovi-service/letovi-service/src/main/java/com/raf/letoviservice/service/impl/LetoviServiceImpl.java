package com.raf.letoviservice.service.impl;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.raf.letoviservice.client.CancelDto;
import com.raf.letoviservice.domain.Avioni;
import com.raf.letoviservice.domain.Letovi;
import com.raf.letoviservice.dto.AvioniCreateDto;
import com.raf.letoviservice.dto.AvioniDto;
import com.raf.letoviservice.dto.BrojMiljaDto;
import com.raf.letoviservice.dto.LetoviCreateDto;
import com.raf.letoviservice.dto.LetoviDto;
import com.raf.letoviservice.dto.PriceDto;
import com.raf.letoviservice.exception.CustomException;
import com.raf.letoviservice.exception.ErrorCode;
import com.raf.letoviservice.exception.NotFoundException;
import com.raf.letoviservice.mapper.LetoviMapper;
import com.raf.letoviservice.repository.AvioniRepository;
import com.raf.letoviservice.repository.LetoviRepository;
import com.raf.letoviservice.security.service.TokenService;
import com.raf.letoviservice.service.LetoviService;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;

@Service
@Transactional
public class LetoviServiceImpl implements LetoviService{
	 private TokenService tokenService;
	 private LetoviMapper letoviMapper;
	 
	 private LetoviRepository letoviRepository;
	 private AvioniRepository avioniRepository;
	 private RestTemplate userServiceRestTemplate;
	 private RestTemplate karteServiceRestTemplate;
	 
	 public LetoviServiceImpl(TokenService tokenService,LetoviMapper letoviMapper,
			 LetoviRepository letoviRepository,AvioniRepository avioniRepository,
			 RestTemplate userServiceRestTemplate,RestTemplate karteServiceRestTemplate) {
		 this.tokenService=tokenService;
		 this.letoviMapper=letoviMapper;
		 this.letoviRepository=letoviRepository;
		 this.avioniRepository=avioniRepository;
		 this.userServiceRestTemplate=userServiceRestTemplate;
		 this.karteServiceRestTemplate=karteServiceRestTemplate;
	 }
	 
	 @Override
	 public Page<LetoviDto> findAll(Pageable pageable){
		 
		 return letoviRepository.findAll(pageable)
	                .map(letoviMapper::letoviToLetoviDto);
	 }
	 
	 @Override
	 public Page<LetoviDto> filterAll(String startDestinacija, String endDestinacija,Pageable pageable){// pretraga po kriterijumu
		 return letoviRepository.findLetoviByStartDestinacijaAndEndDestinacija(startDestinacija, endDestinacija,pageable)
	                .map(letoviMapper::letoviToLetoviDto);
	 }
	 
	 @Override
	 public PriceDto findPrice(Long id) {// prikazi cenu leta bez popusta
		 Letovi letovi = letoviRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("User with id: %d not found.", id)));
	    	BigDecimal bd= letovi.getCena();
	    	
	    	return new PriceDto(bd);
	 }
	 
	 @Override
	 public BrojMiljaDto distance(Long id) { // prikazuje duzinu leta u miljama
		 Letovi letovi = letoviRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("User with id: %d not found.", id)));
	    	Long bd= letovi.getBrojMilja();
	    	
	    	return new BrojMiljaDto(bd); 
	 }
	 
	 @Override
	 public LetoviDto add(LetoviCreateDto letoviCreateDto) {; // dodavanje leta
	 
	 	Avioni avioni = avioniRepository
             .findById(letoviCreateDto.getAvioniId())
             .orElseThrow(() -> new NotFoundException(String
                     .format("airplain with id: %d not found.", letoviCreateDto.getAvioniId())));
	    Letovi letovi = letoviMapper.letoviCreateDtoToLetovi(avioni,letoviCreateDto);
        letoviRepository.save(letovi);
        return letoviMapper.letoviToLetoviDto(letovi);
	    
	 }
	 
	 @Override
	 public void deleteLetovi(Long id) {//brisanje leta
		 Letovi letovi = letoviRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("User with id: %d not found.", id)));
		 if(letovi.getProdateKarte()>0) {
			 //treba poslati info servisu karte da je let obrisan i da obavesti 
			 // sve klijente koji su kupili karte mailom
			 ResponseEntity<CancelDto> re = this.karteServiceRestTemplate.exchange("/kupovina/"+ id +"/flight_cancel",HttpMethod.POST,null,CancelDto.class);
			 Letovi le=letoviRepository.getOne(id);
			 le.setStatus("CANCELED");
			 letoviRepository.save(le);
			 return;
		 }
		 letoviRepository.deleteById(id);
	 }
	 
	 @Override
	 public LetoviDto changeLetovi(Long id, LetoviCreateDto letoviCreateDto) { // update leta
		 Letovi letovi = letoviRepository.findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("Flight >> id: %d not found.", id)));
		 Avioni avioni = avioniRepository
	                .findById(letoviCreateDto.getAvioniId())
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("Avion >> id: %d not found.", id)));
		 
	    	 letovi = letoviMapper.letoviUpdateDtoToLetovi(avioni,letovi, letoviCreateDto);
	    	letoviRepository.save(letovi);
	        return letoviMapper.letoviToLetoviDto(letovi);
		 
	 }
	 
	 @Override
	 public Page<AvioniDto> findAllavioni(Pageable pageable){// prikaz svih aviona
		 return avioniRepository.findAll(pageable)
	                .map(letoviMapper::avioniToAvioniDto);
	 }
	 
	 @Override
	 public AvioniDto addAvioni(AvioniCreateDto avioniCreateDto) { // dodavanje aviona
		 Avioni avioni = letoviMapper.avioniCreateDtoToAvioni(avioniCreateDto);
	        avioniRepository.save(avioni);
	        return letoviMapper.avioniToAvioniDto(avioni);
	 }
	 
	 @Override
	 public void deleteAvioni(Long id) {//brisanje leta
		 //provertiti da li avion pripada nekom letu
		 // ako ne pripada moze da se brise
		 Avioni avioni = avioniRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("Airplain with id: %d not found.", id)));
		 List<Letovi> letovi = letoviRepository
	                .findLetoviByAvioni(avioni);
		 if(letovi.size()>0)throw new CustomException("Avion dodeljen letu", 
				 ErrorCode.RESOURCE_NOT_FOUND, HttpStatus.OK);
	                
		 avioniRepository.deleteById(id);
	 }
	 
	 @Override
	 public AvioniDto changeAvioni(Long id, AvioniCreateDto avioniCreateDto) { // update aviona
		 Avioni avioni = avioniRepository
	                .findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("Airplain with id: %d not found.", id)));
	    	 avioni = letoviMapper.avioniUpdateDtoToAvioni(avioni, avioniCreateDto);
	    	avioniRepository.save(avioni);
	        return letoviMapper.avioniToAvioniDto(avioni);
	 }
	 
	 @Override
	 public LetoviDto getFlight(Long id) {// vraca jedan let
		 Letovi letovi = letoviRepository.findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("Flight >> id: %d not found.", id)));
		 return letoviMapper.letoviToLetoviDto(letovi);
	 }
	 
	 @Override
	 public LetoviDto dodajBrojKupljenihKarata(Long id, Integer num) {
		 Letovi letovi = letoviRepository.findById(id)
	                .orElseThrow(() -> new NotFoundException(String
	                        .format("Flight >> id: %d not found.", id)));
		 
		 letovi.setProdateKarte(letovi.getProdateKarte()+num);
		 letoviRepository.save(letovi);
		 return letoviMapper.letoviToLetoviDto(letovi);
		 
	 
	 }

}
