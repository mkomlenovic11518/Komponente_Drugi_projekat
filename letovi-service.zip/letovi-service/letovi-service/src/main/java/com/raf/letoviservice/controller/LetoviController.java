package com.raf.letoviservice.controller;




import com.raf.letoviservice.dto.*;
import com.raf.letoviservice.security.CheckSecurity;
import com.raf.letoviservice.service.LetoviService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;


@RestController
@RequestMapping("/letovi")
public class LetoviController {
	
	private LetoviService letoviService;
	
	
	public LetoviController(LetoviService letoviService) {
		this.letoviService=letoviService;
	}
	
	@ApiOperation(value = "Get all users")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", value = "What page number you want", dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "size", value = "Number of items to return", dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sort", allowMultiple = true, dataType = "string", paramType = "query",
                    value = "Sorting criteria in the format: property(,asc|desc). " +
                            "Default sort order is ascending. " +
                            "Multiple sort criteria are supported.")})
    //1. vraca sve letove
	@GetMapping
    public ResponseEntity<Page<LetoviDto>> getAllFlights(@RequestHeader("Authorization") String authorization,
                                                     Pageable pageable) {

        return new ResponseEntity<>(letoviService.findAll(pageable), HttpStatus.OK);
    }
	
	//2. pretraga po kriterujumu
	@GetMapping("/{start}/{end}/filter")
    @CheckSecurity(roles = {"ROLE_ADMIN", "ROLE_USER"})
    public ResponseEntity<Page<LetoviDto>> getAllFilter(@RequestHeader("Authorization") String authorization,
    													@PathVariable("start") String start,
    													@PathVariable("end") String end,
    													Pageable pageable) {

        return new ResponseEntity<>(letoviService.filterAll(start,end,pageable), HttpStatus.OK);
    }
	
	//3. dobiijanje cene za let
	@GetMapping("/{id}/cena")
    public ResponseEntity<PriceDto> getCena(@PathVariable("id") Long id) {
        return new ResponseEntity<>(letoviService.findPrice(id), HttpStatus.OK);
    }
	
	//3. dobiijanje jjednog leta
		@GetMapping("/{id}")
	    public ResponseEntity<LetoviDto> getFlight(@PathVariable("id") Long id) {
	        return new ResponseEntity<LetoviDto>(letoviService.getFlight(id), HttpStatus.OK);
	    }
	
	//4. dobiijanje distance u miljama za let
		@GetMapping("/{id}/distanca")
	    public ResponseEntity<BrojMiljaDto> getDistanca(@PathVariable("id") Long id) {
	        return new ResponseEntity<>(letoviService.distance(id), HttpStatus.OK);
	    }
		
	// 5. dodavanje leta, moze samo ADMIN
		@PostMapping("/add_letovi")
	    @CheckSecurity(roles = {"ROLE_ADMIN"})
	    public ResponseEntity<LetoviDto> add(@RequestHeader("Authorization") String authorization,
	    		@RequestBody @Valid LetoviCreateDto letoviCreateDto) {
	        return new ResponseEntity<>(letoviService.add(letoviCreateDto), HttpStatus.CREATED);
	    }
	// 6. brisanje letova moze samo ADMIN
		@DeleteMapping("/{id}/del_letovi")
	    @CheckSecurity(roles = {"ROLE_ADMIN"})
	    public ResponseEntity<?> delete(@RequestHeader("Authorization") String authorization, @PathVariable("id") Long id) {
	        letoviService.deleteLetovi(id);
	        return new ResponseEntity<>(HttpStatus.OK);
	    }
		
		// 7. brisanje aviona moze samo ADMIN
		@DeleteMapping("/{id}/del_avioni")
	    @CheckSecurity(roles = {"ROLE_ADMIN"})
	    public ResponseEntity<?> deleteAvioni(@RequestHeader("Authorization") String authorization, @PathVariable("id") Long id) {
	        letoviService.deleteAvioni(id);
	        return new ResponseEntity<>(HttpStatus.OK);
	    }
		
		// 8. dodavanje aviona, moze samo ADMIN
		@PostMapping("/add_avioni")
	    @CheckSecurity(roles = {"ROLE_ADMIN"})
	    public ResponseEntity<AvioniDto> addAvioni(@RequestHeader("Authorization") String authorization,
	    		@RequestBody @Valid AvioniCreateDto avioniCreateDto) {
	        return new ResponseEntity<>(letoviService.addAvioni(avioniCreateDto), HttpStatus.CREATED);
	    }
		
		//9. prikazi sve avione
		@GetMapping("/all_avioni")
	    @CheckSecurity(roles = {"ROLE_ADMIN", "ROLE_USER"})
	    public ResponseEntity<Page<AvioniDto>> getAllAvioni(@RequestHeader("Authorization") String authorization,
	                                                     Pageable pageable) {

	        return new ResponseEntity<>(letoviService.findAllavioni(pageable), HttpStatus.OK);
	    }
		//10 promeni let, ADMINISTRATOR
		@PutMapping(value="/{id}/changeLet")
		@CheckSecurity(roles = {"ROLE_ADMIN"})
	    public ResponseEntity<LetoviDto> updateLetovi(@RequestHeader("Authorization") String authorization,
	    		@PathVariable(value="id") Long id,@RequestBody @Valid LetoviCreateDto letoviCreateDto) {
	        return new ResponseEntity<LetoviDto>(letoviService.changeLetovi(id, letoviCreateDto), HttpStatus.OK);
	    }
		
		//11 promeni avion, ADMINISTRATOR
		@PutMapping(value = "/{id}/changeAvion")
		@CheckSecurity(roles = {"ROLE_ADMIN"})
	    public ResponseEntity<AvioniDto> updateAvioni(@RequestHeader("Authorization") String authorization,
	    		@PathVariable(value = "id") Long id,@RequestBody @Valid AvioniCreateDto avioniCreateDto) {
	        return new ResponseEntity<AvioniDto>(letoviService.changeAvioni(id, avioniCreateDto), HttpStatus.OK);
	    }
		
		//12 promeni broj karata
		@GetMapping("/{id}/{num}/dodajKarte")
		public ResponseEntity<LetoviDto> dodajKarte(@RequestHeader("Authorization") String authorization,
			    		@PathVariable("id") Long id,@PathVariable("num") Integer num) {
			        return new ResponseEntity<LetoviDto>(letoviService.dodajBrojKupljenihKarata(id, num), HttpStatus.OK);
			    }
		
	

}