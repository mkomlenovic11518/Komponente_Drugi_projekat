package com.raf.letoviservice.dto;

public class BrojMiljaDto {
	
	private Long brojMilja;
	
	public BrojMiljaDto() {}
	
	public BrojMiljaDto(Long l) {
		this.brojMilja=l;
	}

	public Long getBrojMilja() {
		return brojMilja;
	}

	public void setBrojMilja(Long brojMilja) {
		this.brojMilja = brojMilja;
	}

}
