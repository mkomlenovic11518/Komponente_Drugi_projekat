package com.raf.letoviservice.dto;

import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.raf.letoviservice.domain.Avioni;

public class LetoviDto {

    private Long id;
	private String sifraLeta;
 	
    private String startDestinacija;
 	
    private String endDestinacija;
    private Long brojMilja;
    private BigDecimal cena;
    private String status;
    private Integer prodateKarte;
    
    @JsonProperty("avioni")
    private AvioniDto avioniDto;
    
    public LetoviDto() {}

	public String getSifraLeta() {
		return sifraLeta;
	}

	public void setSifraLeta(String sifraLeta) {
		this.sifraLeta = sifraLeta;
	}

	public String getStartDestinacija() {
		return startDestinacija;
	}

	public void setStartDestinacija(String startDestinacija) {
		this.startDestinacija = startDestinacija;
	}

	public String getEndDestinacija() {
		return endDestinacija;
	}

	public void setEndDestinacija(String endDestinacija) {
		this.endDestinacija = endDestinacija;
	}

	public Long getBrojMilja() {
		return brojMilja;
	}

	public void setBrojMilja(Long brojMilja) {
		this.brojMilja = brojMilja;
	}

	public BigDecimal getCena() {
		return cena;
	}

	public void setCena(BigDecimal cena) {
		this.cena = cena;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public AvioniDto getAvioniDto() {
		return avioniDto;
	}

	public void setAvioniDto(AvioniDto avioniDto) {
		this.avioniDto = avioniDto;
	}

	public Integer getProdateKarte() {
		return prodateKarte;
	}

	public void setProdateKarte(Integer prodateKarte) {
		this.prodateKarte = prodateKarte;
	}

}
