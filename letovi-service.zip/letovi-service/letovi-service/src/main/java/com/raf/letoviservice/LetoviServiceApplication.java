package com.raf.letoviservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LetoviServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LetoviServiceApplication.class, args);
	}

}
