package com.raf.letoviservice.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Avioni {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String ime;
    private Long broj_sedista;

    public Avioni() {

    }

    public Avioni(String title,  Long bs) {
        this.setIme(title);
        
        this.setBroj_sedista(bs);
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	
	public Long getBroj_sedista() {
		return broj_sedista;
	}

	public void setBroj_sedista(Long broj_sedista) {
		this.broj_sedista = broj_sedista;
	}


}
