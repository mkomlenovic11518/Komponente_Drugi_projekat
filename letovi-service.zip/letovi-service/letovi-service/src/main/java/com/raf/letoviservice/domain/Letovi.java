package com.raf.letoviservice.domain;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;



@Entity
public class Letovi {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne
    private Avioni avioni;
    private String sifraLeta;
    private String startDestinacija;
    private String endDestinacija;
    private Long brojMilja;
    private BigDecimal cena;
    private Integer prodateKarte;
    private String status;
    
    public Letovi() {}
    public Letovi(Avioni a, String sif, String start, String end, Long bm, BigDecimal c, Integer pk, String status) {
    	this.avioni=a;
    	this.setSifraLeta(sif);
    	this.setStartDestinacija(start);
    	this.setEndDestinacija(end);
    	this.setBrojMilja(bm);
    	this.setCena(c);
    	this.setProdateKarte(pk);
    	this.setStatus(status);
    }
	public String getSifraLeta() {
		return sifraLeta;
	}
	public void setSifraLeta(String sifraLeta) {
		this.sifraLeta = sifraLeta;
	}
	public String getStartDestinacija() {
		return startDestinacija;
	}
	public void setStartDestinacija(String startDestinacija) {
		this.startDestinacija = startDestinacija;
	}
	public String getEndDestinacija() {
		return endDestinacija;
	}
	public void setEndDestinacija(String endDestinacija) {
		this.endDestinacija = endDestinacija;
	}
	public Long getBrojMilja() {
		return brojMilja;
	}
	public void setBrojMilja(Long brojMilja) {
		this.brojMilja = brojMilja;
	}
	public BigDecimal getCena() {
		return cena;
	}
	public void setCena(BigDecimal cena) {
		this.cena = cena;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Avioni getAvioni() {
		return avioni;
	}
	public void setAvioni(Avioni a) {
		this.avioni = a;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getProdateKarte() {
		return prodateKarte;
	}
	public void setProdateKarte(Integer prodateKarte) {
		this.prodateKarte = prodateKarte;
	}

}
