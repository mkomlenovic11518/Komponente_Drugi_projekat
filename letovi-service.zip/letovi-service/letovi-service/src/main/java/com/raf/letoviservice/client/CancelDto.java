package com.raf.letoviservice.client;

public class CancelDto {
	private Long status;
	public CancelDto(Long i) {
		this.status=i;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}
	

}
