package com.raf.letoviservice.exception;

public enum ErrorCode {
    RESOURCE_NOT_FOUND
}
