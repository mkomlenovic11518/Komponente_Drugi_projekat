package com.raf.letoviservice.mapper;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.raf.letoviservice.domain.Avioni;
import com.raf.letoviservice.domain.Letovi;
import com.raf.letoviservice.dto.AvioniCreateDto;
import com.raf.letoviservice.dto.AvioniDto;
import com.raf.letoviservice.dto.LetoviCreateDto;
import com.raf.letoviservice.dto.LetoviDto;
import com.raf.letoviservice.repository.AvioniRepository;
import com.raf.letoviservice.repository.LetoviRepository;

@Component
public class LetoviMapper {
	
	private LetoviRepository letoviRepository;
	private AvioniRepository avioniRepository;
	
	// mapiranje za select
	public LetoviDto letoviToLetoviDto(Letovi letovi) {
		
		LetoviDto letoviDto=new LetoviDto();
		letoviDto.setId(letovi.getId());
		letoviDto.setSifraLeta(letovi.getSifraLeta());
		letoviDto.setStartDestinacija(letovi.getStartDestinacija());
		letoviDto.setEndDestinacija(letovi.getEndDestinacija());
		letoviDto.setBrojMilja(letovi.getBrojMilja());
		letoviDto.setCena(letovi.getCena());
		
		letoviDto.setProdateKarte(letovi.getProdateKarte());
		letoviDto.setStatus(letovi.getStatus());
		
		AvioniDto avioniDto=new AvioniDto();
		avioniDto.setId(letovi.getAvioni().getId());
		avioniDto.setIme(letovi.getAvioni().getIme());
		avioniDto.setBroj_sedista(letovi.getAvioni().getBroj_sedista());
		letoviDto.setAvioniDto(avioniDto);
		
		return letoviDto;
	}
	
	//mapiranje za create
	public Letovi letoviCreateDtoToLetovi(Avioni avioni, LetoviCreateDto letoviCreateDto) {
		Letovi letovi=new Letovi();
		//pronalazimo objekat Avioni na bazi id aviona
		letovi.setAvioni(avioni);
		letovi.setBrojMilja(letoviCreateDto.getBrojMilja());
		letovi.setCena(letoviCreateDto.getCena());
		letovi.setStartDestinacija(letoviCreateDto.getStartDestinacija());
		letovi.setEndDestinacija(letoviCreateDto.getEndDestinacija());
		letovi.setSifraLeta(letoviCreateDto.getSifraLeta());
		letovi.setStatus(letoviCreateDto.getStatus());
		letovi.setProdateKarte(letoviCreateDto.getProdateKarte());
		
		return letovi;
	}
	
	// mapiranje za update
	public Letovi letoviUpdateDtoToLetovi(Avioni avioni,Letovi letovi, LetoviCreateDto letoviCreateDto) {
		
		//pronalazimo objekat Avioni na bazi id aviona
		letovi.setAvioni(avioni);
		letovi.setBrojMilja(letoviCreateDto.getBrojMilja());
		letovi.setCena(letoviCreateDto.getCena());
		letovi.setStartDestinacija(letoviCreateDto.getStartDestinacija());
		letovi.setEndDestinacija(letoviCreateDto.getEndDestinacija());
		letovi.setSifraLeta(letoviCreateDto.getSifraLeta());
		letovi.setStatus(letoviCreateDto.getStatus());
		letovi.setProdateKarte(letoviCreateDto.getProdateKarte());
		return letovi;
	}
	
	// mapiranje za select
		public AvioniDto avioniToAvioniDto(Avioni avioni) {
			
			AvioniDto avioniDto=new AvioniDto();
			avioniDto.setId(avioni.getId());
			avioniDto.setIme(avioni.getIme());
			avioniDto.setBroj_sedista(avioni.getBroj_sedista());
			return avioniDto;
		}
		
		//mapiranje za create
		public Avioni avioniCreateDtoToAvioni(AvioniCreateDto avioniCreateDto) {
			Avioni avioni=new Avioni();
			avioni.setIme(avioniCreateDto.getIme());
			avioni.setBroj_sedista(avioniCreateDto.getBroj_sedista());
			
			return avioni;
		}
		
		//mapiranje za update
		public Avioni avioniUpdateDtoToAvioni(Avioni avioni, AvioniCreateDto avioniCreateDto) {
			
			avioni.setIme(avioniCreateDto.getIme());
			avioni.setBroj_sedista(avioniCreateDto.getBroj_sedista());
			
			return avioni;
		}
	

}
