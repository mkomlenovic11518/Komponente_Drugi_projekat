package com.raf.letoviservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.raf.letoviservice.domain.Avioni;
import com.raf.letoviservice.domain.Letovi;



@Repository
public interface LetoviRepository extends JpaRepository<Letovi, Long>{
	Page<Letovi> findLetoviByStartDestinacijaAndEndDestinacija(String startDestinacija, String endDestinacija,Pageable p);
	
	List<Letovi> findLetoviByAvioni(Avioni avioni);

}
