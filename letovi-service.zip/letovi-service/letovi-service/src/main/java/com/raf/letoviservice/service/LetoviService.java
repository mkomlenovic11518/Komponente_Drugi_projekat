package com.raf.letoviservice.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


import com.raf.letoviservice.dto.*;

public interface LetoviService {
	
	Page<LetoviDto> findAll(Pageable pageable);// prikaz svih letova
	
	Page<LetoviDto> filterAll(String startDest, String endDest, Pageable pageable);// pretraga po kriterijumu
	
	PriceDto findPrice(Long id);// prikazi cenu leta bez popusta
	
	BrojMiljaDto distance(Long id); // prikazuje duzinu leta u miljama
	
	LetoviDto add(LetoviCreateDto letoviCreateDto); // dodavanje leta
	
	LetoviDto changeLetovi(Long id, LetoviCreateDto letoviCreateDto); // update leta
	
	void deleteLetovi(Long id);//brisanje leta
	
	Page<AvioniDto> findAllavioni(Pageable pageable);// prikaz svih aviona
	
	AvioniDto addAvioni(AvioniCreateDto avioniCreateDto); // dodavanje aviona
	
	void deleteAvioni(Long id);//brisanje leta
	
	AvioniDto changeAvioni(Long id, AvioniCreateDto avioniCreateDto); // update aviona
	
	LetoviDto getFlight(Long id);//vraca jedan let
	
	LetoviDto dodajBrojKupljenihKarata(Long id, Integer num);//ovom metodom se salje info o kupljenim

}
