package com.raf.letoviservice.dto;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

public class AvioniCreateDto {
	
	@NotBlank
	private String ime;
	
    private Long broj_sedista;
    
    public AvioniCreateDto() {
    	
    }

	

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	
	public Long getBroj_sedista() {
		return broj_sedista;
	}

	public void setBroj_sedista(Long broj_sedista) {
		this.broj_sedista = broj_sedista;
	}
   

}
