package com.raf.letoviservice.dto;

import java.math.BigDecimal;

import com.raf.letoviservice.domain.Avioni;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

public class LetoviCreateDto {
		
		
	 	private Long avioniId;
	 	@Length(min = 3, max = 5)
	    private String sifraLeta;
	 	@NotBlank
	    private String startDestinacija;
	 	@NotBlank
	    private String endDestinacija;
	    private Long brojMilja;
	    private BigDecimal cena;
	    private String status;
	    private Integer prodateKarte;

	    public LetoviCreateDto() {}

		

		public String getSifraLeta() {
			return sifraLeta;
		}

		public void setSifraLeta(String sifraLeta) {
			this.sifraLeta = sifraLeta;
		}

		public String getStartDestinacija() {
			return startDestinacija;
		}

		public void setStartDestinacija(String startDestinacija) {
			this.startDestinacija = startDestinacija;
		}

		public String getEndDestinacija() {
			return endDestinacija;
		}

		public void setEndDestinacija(String endDestinacija) {
			this.endDestinacija = endDestinacija;
		}

		public Long getBrojMilja() {
			return brojMilja;
		}

		public void setBrojMilja(Long brojMilja) {
			this.brojMilja = brojMilja;
		}

		public BigDecimal getCena() {
			return cena;
		}

		public void setCena(BigDecimal cena) {
			this.cena = cena;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public Long getAvioniId() {
			return avioniId;
		}

		public void setAvioniId(Long avioniId) {
			this.avioniId = avioniId;
		}



		public Integer getProdateKarte() {
			return prodateKarte;
		}



		public void setProdateKarte(Integer prodateKarte) {
			this.prodateKarte = prodateKarte;
		}



	    
	    
}
