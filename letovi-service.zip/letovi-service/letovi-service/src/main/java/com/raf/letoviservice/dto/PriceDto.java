package com.raf.letoviservice.dto;

import java.math.BigDecimal;

public class PriceDto {
	
	private BigDecimal cena;
	public PriceDto(){}
	
	public PriceDto(BigDecimal c) {
		this.cena=c;
	}
	public BigDecimal getCena() {
		return cena;
	}
	public void setCena(BigDecimal cena) {
		this.cena = cena;
	}

}
