package com.raf.letoviservice.runner;


import java.math.BigDecimal;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.raf.letoviservice.domain.Avioni;
import com.raf.letoviservice.domain.Letovi;
import com.raf.letoviservice.repository.AvioniRepository;
import com.raf.letoviservice.repository.LetoviRepository;

@Profile({"default"})
@Component
public class TestDataRunner implements CommandLineRunner {

	
	
   
    private LetoviRepository letoviRepository;
    private AvioniRepository avioniRepository;
    @Override
    public void run(String... args) throws Exception {}

   /* public TestDataRunner(LetoviRepository letoviRepository,AvioniRepository avioniRepository) {
        this.letoviRepository = letoviRepository;
        this.avioniRepository = avioniRepository;
      
    }

    @Override
    public void run(String... args) throws Exception {
        //Insert avion
         Avioni avioni=new Avioni();
         avioni.setIme("A123 Boeing");
         avioni.setBroj_sedista(new Long(300));
         avioniRepository.save(avioni);
        //Insert letovi
        Letovi letovi=new Letovi();
        letovi.setAvioni(avioni);
        letovi.setBrojMilja(new Long(1000));
        letovi.setCena(new BigDecimal(850));
        letovi.setSifraLeta("L001");
        letovi.setStartDestinacija("Beograd");
        letovi.setEndDestinacija("Prag");
        letovi.setStatus("PENDING");
        letoviRepository.save(letovi);
       
    }   */
}
