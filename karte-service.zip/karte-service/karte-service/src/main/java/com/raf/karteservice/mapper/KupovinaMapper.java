package com.raf.karteservice.mapper;

import org.springframework.stereotype.Component;

import com.raf.karteservice.domain.KupovinaKarte;
import com.raf.karteservice.dto.KupovinaCreateDto;
import com.raf.karteservice.dto.KupovinaDto;

@Component
public class KupovinaMapper {
	
	public KupovinaDto KupovinaKarteToKupovinaDto(KupovinaKarte kk) {
		KupovinaDto kupovinaDto=new KupovinaDto();
		
		kupovinaDto.setId(kk.getId());
		kupovinaDto.setUserId(kk.getUserId());
		kupovinaDto.setLetId(kk.getLetId());
		kupovinaDto.setDatum(kk.getDatum());
		kupovinaDto.setBroj_karata_kupovine(kk.getBroj_karata_kupovine());
		kupovinaDto.setPrice(kk.getPrice());
		kupovinaDto.setStatus(kk.getStatus());
		kupovinaDto.setBr_platne_kartice(kk.getBr_platne_kartice());
		return kupovinaDto;
	}
	
	public KupovinaKarte KupovinaCreateDtoToKupovinaKarte(KupovinaCreateDto kk) {
		KupovinaKarte kupovinaKarte=new KupovinaKarte();
		kupovinaKarte.setUserId(kk.getUserId());
		kupovinaKarte.setLetId(kk.getLetId());
		kupovinaKarte.setBroj_karata_kupovine(kk.getBroj_karata_kupovine());
		kupovinaKarte.setBr_platne_kartice(kk.getBr_platne_kartice());
		kupovinaKarte.setStatus(kk.getStatus());
		kupovinaKarte.setDatum(kk.getDatum());
		kupovinaKarte.setPrice(kk.getPrice());
		
		return kupovinaKarte;
	}

}
