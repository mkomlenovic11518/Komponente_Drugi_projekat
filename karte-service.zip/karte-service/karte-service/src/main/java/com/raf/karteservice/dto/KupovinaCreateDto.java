package com.raf.karteservice.dto;

import java.math.BigDecimal;
import java.util.Date;

public class KupovinaCreateDto {
	private long userId;
	private long letId;
	private Date datum;
	private BigDecimal price;
	private int broj_karata_kupovine;
	private String status;
	private String br_platne_kartice;
	
	public KupovinaCreateDto() {}
	public KupovinaCreateDto(long us,long lt, int bk,Date dt,BigDecimal pr,
			String status,String br_platne_kartice) {
		this.setUserId(us);
		this.setLetId(lt);
		this.setBroj_karata_kupovine(bk);
		this.datum=dt;
		this.setPrice(pr);
		this.status=status;
		this.br_platne_kartice=br_platne_kartice;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getLetId() {
		return letId;
	}
	public void setLetId(long letId) {
		this.letId = letId;
	}
	public int getBroj_karata_kupovine() {
		return broj_karata_kupovine;
	}
	public void setBroj_karata_kupovine(int broj_karata_kupovine) {
		this.broj_karata_kupovine = broj_karata_kupovine;
	}
	public Date getDatum() {
		return datum;
	}
	public void setDatum(Date datum) {
		this.datum = datum;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBr_platne_kartice() {
		return br_platne_kartice;
	}
	public void setBr_platne_kartice(String br_platne_kartice) {
		this.br_platne_kartice = br_platne_kartice;
	}

}
