package com.raf.karteservice.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.raf.karteservice.dto.KupovinaCreateDto;
import com.raf.karteservice.dto.KupovinaDto;

public interface KupovinaService {
	
	KupovinaDto addKupovina(KupovinaCreateDto kupovinaCreateDto);
	
	void flightCancel(Long id);
	
	Page<KupovinaDto> getKarte(Long user_id,Pageable pageable);

}
