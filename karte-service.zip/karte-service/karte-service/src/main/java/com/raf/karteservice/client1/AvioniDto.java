package com.raf.karteservice.client1;

public class AvioniDto {
	
	 private Long id;
	    private String ime;
	   
	    private Long broj_sedista;
	    
	    public AvioniDto() {
	    	
	    }

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getIme() {
			return ime;
		}

		public void setIme(String ime) {
			this.ime = ime;
		}

		
		public Long getBroj_sedista() {
			return broj_sedista;
		}

		public void setBroj_sedista(Long broj_sedista) {
			this.broj_sedista = broj_sedista;
		}
	   
}
