package com.raf.karteservice.exception;

public enum ErrorCode {
    RESOURCE_NOT_FOUND
}
