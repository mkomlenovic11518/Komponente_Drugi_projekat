package com.raf.karteservice.domain;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.Date;

@Entity
public class KupovinaKarte {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	private long userId;
	private long letId;
	private BigDecimal price;
	
	private Date datum;
	private int broj_karata_kupovine;
	private String status;
	private String br_platne_kartice;
	
	public KupovinaKarte() {}
	
	public KupovinaKarte(long us, long let, BigDecimal cn, Date datum, int broj_karata_kupovine,
			String status,String br_platne_kartice) {
		this.setUserId(us);
		this.setLetId(let);
		this.setPrice(cn);
		this.setDatum(datum);
		this.status=status;
		this.br_platne_kartice=br_platne_kartice;
		this.setBroj_karata_kupovine(broj_karata_kupovine);
		
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getLetId() {
		return letId;
	}
	public void setLetId(long letId) {
		this.letId = letId;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Date getDatum() {
		return datum;
	}

	public void setDatum(Date datum) {
		this.datum = datum;
	}

	public int getBroj_karata_kupovine() {
		return broj_karata_kupovine;
	}

	public void setBroj_karata_kupovine(int broj_karata_kupovine) {
		this.broj_karata_kupovine = broj_karata_kupovine;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBr_platne_kartice() {
		return br_platne_kartice;
	}

	public void setBr_platne_kartice(String br_platne_kartice) {
		this.br_platne_kartice = br_platne_kartice;
	}
	
	

}
