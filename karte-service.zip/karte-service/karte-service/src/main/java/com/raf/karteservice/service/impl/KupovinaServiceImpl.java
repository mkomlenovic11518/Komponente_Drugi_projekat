package com.raf.karteservice.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.raf.karteservice.client1.DiscountDto;
import com.raf.karteservice.client1.LetoviDto;
import com.raf.karteservice.client1.NumberOfMillesDto;
import com.raf.karteservice.client1.UserDto;
import com.raf.karteservice.domain.KupovinaKarte;
import com.raf.karteservice.domain.Log;
import com.raf.karteservice.dto.KupovinaCreateDto;
import com.raf.karteservice.dto.KupovinaDto;
import com.raf.karteservice.exception.CustomException;
import com.raf.karteservice.exception.ErrorCode;
import com.raf.karteservice.mapper.KupovinaMapper;

import com.raf.karteservice.repository.KupovinaRepository;
import com.raf.karteservice.repository.LogRepository;
import com.raf.karteservice.service.KupovinaService;

@Service
public class KupovinaServiceImpl implements KupovinaService {
	private KupovinaRepository kupovinaRepository;
	private LogRepository logRepository;
	
	private RestTemplate letServiceRestTemplate;
	private RestTemplate userServiceRestTemplate;
	
	private KupovinaMapper kupovinaMapper;
	
	public KupovinaServiceImpl(KupovinaRepository kr,LogRepository logRepository,@Qualifier("letServiceRestTemplate") RestTemplate let,
					@Qualifier("userServiceRestTemplate") RestTemplate usr,@Qualifier("kupovinaMapper")KupovinaMapper km  ) {
		this.kupovinaRepository=kr;
		this.letServiceRestTemplate=let;
		this.userServiceRestTemplate=usr;
		this.kupovinaMapper=km;
		this.logRepository=logRepository;
	}
	
	@Override
	public void flightCancel(Long id) {
		// dobijena je poruka da je let sa id otkazan
		// potrebno je da servis karte obavesti servis user kako bi ovaj poslao mailove klijentima
		// info treba da sadrzi informacije o klijentima i poruku za user servis
		ResponseEntity<LetoviDto> let = this.letServiceRestTemplate.exchange("/letovi/"+ id,HttpMethod.GET,null,LetoviDto.class);
		long milje=-(let.getBody().getBrojMilja());
		List<KupovinaKarte> kupovina = this.kupovinaRepository.findByLetId(id);
		for (int i=0;i<kupovina.size();i++) {
			
			
			//poziv user service da otkaze milje i da posalje mailove o otkazivanju
			ResponseEntity<UserDto> re1 = this.userServiceRestTemplate.exchange("/user/"+ kupovina.get(i).getUserId()+"/cancelKupovine",HttpMethod.GET,null,UserDto.class);
			// poziv da promeni broj milja
			ResponseEntity<NumberOfMillesDto> re3 = this.userServiceRestTemplate.exchange("/user/"+ kupovina.get(i).getUserId()+"/" +milje+ "/changeMilles",HttpMethod.GET,null,NumberOfMillesDto.class);
			KupovinaKarte kk = kupovina.get(i);
			kk.setStatus("CANCELED");
			kupovinaRepository.save(kk);
		}
	}
	
	@Override
	public KupovinaDto addKupovina(KupovinaCreateDto kd) {
		//ako zelimo da izracunamo cenu karte onda nam trba cena leta
		// i popust koji ima user.
		// POZIV SERVIS LETOVI-SERVICE i TRAZENJE PODATAKA O LETU I REGULARNOJ CENI
		ResponseEntity<LetoviDto> re = this.letServiceRestTemplate.exchange("/letovi/"+ kd.getLetId(),HttpMethod.GET,null,LetoviDto.class);
		
		
		BigDecimal cena=BigDecimal.ONE;
		cena=re.getBody().getCena();
		long milje=re.getBody().getBrojMilja();
		// treba videti da li postoji popust
		// POZIV SERVIS USER-SERVICE i TRAZENJE PODATAKA O POPUSTU
		ResponseEntity<DiscountDto> re1 = this.userServiceRestTemplate.exchange("/user/"+ kd.getUserId()+"/discount",HttpMethod.GET,null,DiscountDto.class);
		BigDecimal popust=new BigDecimal(re1.getBody().getDiscount());
		double ponder=1-(popust.floatValue()*0.01);
		BigDecimal ponderb=new BigDecimal(ponder);
		//finlana cena
		cena=cena.multiply(ponderb);
		Long broj_mesta_avion=re.getBody().getAvioniDto().getBroj_sedista();
		int br_popunjenih_let=re.getBody().getProdateKarte(); //vec prodate karte
		if(kd.getBroj_karata_kupovine()+br_popunjenih_let> broj_mesta_avion) {
			
			throw new CustomException("Avion nema dovoljno slobodnih mesta", ErrorCode.RESOURCE_NOT_FOUND, HttpStatus.CONFLICT);
			
		}
		KupovinaKarte kk= new KupovinaKarte(kd.getUserId(),kd.getLetId(),cena, new Date(),kd.getBroj_karata_kupovine(),
				kd.getStatus(),kd.getBr_platne_kartice());
		
		this.kupovinaRepository.save(kk);
		String s1="/letovi/"+ kd.getLetId()+"/"+kd.getBroj_karata_kupovine()+"/dodajKarte";
		// POZIV SERVIS LETOVI-SERVICE i AZURIRANJE BROJA PRODATIH KARATA LETA
		ResponseEntity<LetoviDto> re2 = this.letServiceRestTemplate.exchange(s1,HttpMethod.GET,null,LetoviDto.class);
		String s2=re2.getBody().getProdateKarte().toString();
		Log lg=new Log();
		lg.setLog1(s1);
		lg.setLog2(s2);
		lg.setDatum(new Date());
		logRepository.save(lg);
		// POZIV SERVIS USER-SERVICE i AZURIRANJE BROJA MILJA ZA USERA
		ResponseEntity<NumberOfMillesDto> re3 = this.userServiceRestTemplate.exchange("/user/"+ kd.getUserId()+"/" +milje+ "/changeMilles",HttpMethod.GET,null,NumberOfMillesDto.class);
		lg.setLog1("/user/"+ kd.getUserId()+"/" +milje+ "/changeMilles");
		Log lg1=new Log();
		lg1.setLog2(re3.getBody().getNumberOfMillesDto().toString());
		lg1.setDatum(new Date());
		logRepository.save(lg1);
		return kupovinaMapper.KupovinaKarteToKupovinaDto(kk);
		
		
				
	}
	

	@Override
	 public Page<KupovinaDto> getKarte(Long user_id,Pageable pageable){// pretraga po kriterijumu
		 return kupovinaRepository.findKupovinaKarteByUserId(user_id,pageable)
	                .map(kupovinaMapper::KupovinaKarteToKupovinaDto);
	 }

}
