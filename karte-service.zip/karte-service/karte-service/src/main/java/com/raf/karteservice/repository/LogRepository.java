package com.raf.karteservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.raf.karteservice.domain.KupovinaKarte;
import com.raf.karteservice.domain.Log;

public interface LogRepository  extends JpaRepository<Log,Long> {

}
