package com.raf.karteservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.raf.karteservice.dto.KupovinaCreateDto;
import com.raf.karteservice.dto.KupovinaDto;
import com.raf.karteservice.service.KupovinaService;


import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;


@RestController
@RequestMapping("/kupovina")
public class KupovinaController {
	
	@Autowired
	private KupovinaService kupovinaService;
	
	/*public KupovinaController(KupovinaService kupovinaService) {
		this.kupovinaService=kupovinaService;
	}*/
	
	@ApiOperation(value = "Get all kupovine")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", value = "What page number you want", dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "size", value = "Number of items to return", dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sort", allowMultiple = true, dataType = "string", paramType = "query",
                    value = "Sorting criteria in the format: property(,asc|desc). " +
                            "Default sort order is ascending. " +
                            "Multiple sort criteria are supported.")})
	
	@PostMapping
	public ResponseEntity<KupovinaDto> addKupovina(@RequestBody @Validated KupovinaCreateDto kupovinaCreateDto){
		
		return new ResponseEntity<KupovinaDto>(kupovinaService.addKupovina(kupovinaCreateDto),HttpStatus.CREATED);
	}
	
	@PostMapping("{id}/flight_cancel")
	public ResponseEntity<?> flightCancel(@PathVariable("id") Long id){
		kupovinaService.flightCancel(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	//3. dobiijanje karata jednog usera
	@GetMapping("/{user_id}")
    public ResponseEntity<Page<KupovinaDto>> getFlight(@PathVariable("user_id") Long user_id, Pageable pageable) {
        return new ResponseEntity<Page<KupovinaDto>>(kupovinaService.getKarte(user_id,pageable), HttpStatus.OK);
    }

}
